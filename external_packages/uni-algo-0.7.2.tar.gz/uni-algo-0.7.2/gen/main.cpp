/* Generator for Unicode Algorithms Implementation.
 * License: Public Domain or MIT - choose whatever you want.
 * See LICENSE.md */

#include "gen.h"

int main()
{
    main3();

    return 0;
}
