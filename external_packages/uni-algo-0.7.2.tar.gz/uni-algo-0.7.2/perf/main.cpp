/* Performance test for Unicode Algorithms Implementation.
 * License: Public Domain or MIT - choose whatever you want.
 * See LICENSE.md */

// The performance test is a mess. If you want to use it you're on your own.

#include "perf_convert_utf8to16.h"
//#include "perf_normalize_nfc_utf16.h"
//#include "perf_normalize_nfc_utf8.h"
//#include "perf_break_utf16.h"
//#include "perf_transform_utf16.h"

int main()
{
    main5();
    return 0;
}
