/* C++ Standard Library wrapper for Unicode Algorithms Implementation.
 * License: Public Domain or MIT - choose whatever you want.
 * See LICENSE.md */

#include "../include/uni_algo/internal/data_inl.h"
#include "../include/uni_algo/internal/locale_inl.h"
