// GENERATED. DO NOT EDIT.

// Unicode 15.0.0

UNI_ALGO_IMPL_NAMESPACE_BEGIN

UNI_ALGO_DLL extern const uaix_data_array(unsigned char, stage1_prop, 8704);
UNI_ALGO_DLL extern const uaix_data_array(unsigned char, stage2_prop, 32640);

UNI_ALGO_IMPL_NAMESPACE_END
