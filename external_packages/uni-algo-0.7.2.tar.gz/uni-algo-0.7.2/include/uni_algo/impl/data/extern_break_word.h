// GENERATED. DO NOT EDIT.

// Unicode 15.0.0

UNI_ALGO_IMPL_NAMESPACE_BEGIN

UNI_ALGO_DLL extern const uaix_data_array(unsigned char, stage1_break_word, 8704);
UNI_ALGO_DLL extern const uaix_data_array(unsigned char, stage2_break_word, 29056);

UNI_ALGO_IMPL_NAMESPACE_END
