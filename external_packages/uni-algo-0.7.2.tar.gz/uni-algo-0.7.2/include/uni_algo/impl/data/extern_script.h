// GENERATED. DO NOT EDIT.

// Unicode 15.0.0

UNI_ALGO_IMPL_NAMESPACE_BEGIN

UNI_ALGO_DLL extern const uaix_data_array(unsigned char, stage1_script, 8704);
UNI_ALGO_DLL extern const uaix_data_array(unsigned char, stage2_script, 31744);
UNI_ALGO_DLL extern const uaix_data_array(type_codept,   stage3_script, 164);

UNI_ALGO_DLL extern const uaix_data_array(unsigned char,  stage1_script_ext, 8704);
UNI_ALGO_DLL extern const uaix_data_array(unsigned short, stage2_script_ext, 5888);
UNI_ALGO_DLL extern const uaix_data_array(type_codept,    stage3_script_ext, 708);

UNI_ALGO_IMPL_NAMESPACE_END
