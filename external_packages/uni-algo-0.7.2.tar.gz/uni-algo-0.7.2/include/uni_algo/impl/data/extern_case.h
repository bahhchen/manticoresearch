// GENERATED. DO NOT EDIT.

// Unicode 15.0.0

UNI_ALGO_IMPL_NAMESPACE_BEGIN

UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage1_lower, 8704);
UNI_ALGO_DLL extern const uaix_data_array(type_codept,     stage2_lower, 4608);
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage1_upper, 8704);
UNI_ALGO_DLL extern const uaix_data_array(type_codept,     stage2_upper, 5376);
#ifndef UNI_ALGO_DISABLE_BREAK_WORD
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage1_title, 8704);
UNI_ALGO_DLL extern const uaix_data_array(type_codept,     stage2_title, 5248);
#endif
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage1_fold, 8704);
UNI_ALGO_DLL extern const uaix_data_array(type_codept,     stage2_fold, 4864);
UNI_ALGO_DLL extern const uaix_data_array(unsigned short,  stage1_order, 8704);
UNI_ALGO_DLL extern const uaix_data_array(unsigned short,  stage2_order, 40320);
#ifndef UNI_ALGO_DISABLE_FULL_CASE
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage1_special_upper, 512);
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage2_special_upper, 1280);
UNI_ALGO_DLL extern const uaix_data_array2(unsigned short, stage3_special_upper, 103, 4);
#if 0
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage1_special_lower, 512);
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage2_special_lower, 256);
UNI_ALGO_DLL extern const uaix_data_array2(unsigned short, stage3_special_lower, 2, 4);
#endif
#ifndef UNI_ALGO_DISABLE_BREAK_WORD
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage1_special_title, 512);
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage2_special_title, 1280);
UNI_ALGO_DLL extern const uaix_data_array2(unsigned short, stage3_special_title, 49, 4);
#endif
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage1_special_fold, 512);
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage2_special_fold, 1280);
UNI_ALGO_DLL extern const uaix_data_array2(unsigned short, stage3_special_fold, 105, 4);
#endif
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage1_case_prop, 8704);
UNI_ALGO_DLL extern const uaix_data_array(unsigned char,   stage2_case_prop, 20736);

UNI_ALGO_IMPL_NAMESPACE_END
