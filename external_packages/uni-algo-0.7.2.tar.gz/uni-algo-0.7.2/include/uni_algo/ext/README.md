**DRAFT**

This directory contains extensions for uni-algo library.

Note that the extensions use unx:: namespace intead of una:: namespace.

All the extensions are header-only.

API of the extensions is stable only across minor versions instead of major.<br>
This doesn't mean that extensions are experimental they all properly tested.
