/* SQLite Extension for Unicode Algorithms Implementation.
 * License: Public Domain or MIT - choose whatever you want.
 * See LICENSE.md */

#ifdef __cplusplus
extern "C" {
#endif

void uni_sqlite3_init();

#ifdef __cplusplus
} // extern "C"
#endif
